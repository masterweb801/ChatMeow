<?php
  $hostname = "localhost";
  $username = "id20455309_pvweb";
  $password = "X-)!4Vt6~KfOpo1@";
  $dbname = "id20455309_chatapp";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
