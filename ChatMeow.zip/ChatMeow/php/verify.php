<?php
  session_start();
  if(isset($_SESSION['unique_id'])){
    include_once "config.php";
    $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = '{$_SESSION['unique_id']}'");
    $row = mysqli_fetch_assoc($sql);
    if($row['verify']=="False"){
      header("location: verificatio.php")
    }
  }
?>
