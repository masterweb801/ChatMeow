<?php
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CHATMEOW</title>
    <link rel="apple-touch-icon" sizes="180x180" href="/php/images/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/php/images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/php/images/favicon-16x16.png">
    <link rel="manifest" href="/php/images/site.webmanifest">

    <link rel="stylesheet" href="nav.css">
    <script src="https://kit.fontawesome.com/171e689b28.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  </head>
  <body>
    <nav>
      <?php
        $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
        if(mysqli_num_rows($sql) > 0){
          $row = mysqli_fetch_assoc($sql);
        }
      ?>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <img src="../php/images/<?php echo $row['img'] ?>" style="width:50px; height:50px; border-radius:50%; object-fit:cover; margin-top:20px;">
      </label>
      <label class="logo"><?php echo $row['fname'] ?></label>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Feedback</a></li>
        <li><a href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>">Logout</a></li>
      </ul>
    </nav>
    <section class="users">
	<div class="search">
        <span class="text" style="color:grey;">Select an user to start chat</span>
        <input type="text" placeholder="Enter name to search...">
        <button><i class="fas fa-search"></i></button>
      </div>
      <div class="users-list">
      </div>
    </section>
    <script src="javascript/users.js"></script>
  </body>
</html>
