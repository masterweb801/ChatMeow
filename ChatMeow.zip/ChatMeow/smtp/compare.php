<?php
  if (isset($_GET['otp'])) {
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<meta http-equiv="X-UA-Compatible" content="ie=edge">';
    echo '<link rel="apple-touch-icon" sizes="180x180" href="../php/images/apple-touch-icon.png">';
    echo '<title>CHATMEOW</title>';
    echo '<link rel="icon" type="image/png" sizes="32x32" href="../php/images/favicon-32x32.png">';
    echo '<link rel="icon" type="image/png" sizes="16x16" href="../php/images/favicon-16x16.png">';
    echo '<link rel="manifest" href="../php/images/site.webmanifest">';
    echo '<link rel="stylesheet" href="../style.css">';
    echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>';
    echo '<head>';
    echo '<body>';
    echo '<div class="wrapper">';
    echo '<section class="form login">';
    echo '<header>Verify Your Email</header>';
    echo '<form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">';
    echo '<div class="error-text"></div>';
    echo '<div class="field input">';
    echo '<label> Enter Your OTP </label>';
    echo '<input type="text" name="usr" placeholder="Enter 6 Digit Code" required>';
    echo '</div>';
    echo '<div class="field button">';
    echo '<input type="submit" name="submit" value="Verify">';
    echo '</div>';
    echo '</form>';
    echo '</section>';
    echo '</div>';
    echo '</body>';
    echo '</html>';

    if (isset($_POST['usr'])) {
      if ($_GET['otp']==$_POST['usr']) {
       mail($_GET['mail'], "Email Verification ChatMeow", "Your Email Is Verified!", "From: chatmeow@official.com");
      }
    }
  }
?>
