<?php
  if (isset($_REQUEST['email']))  {
  $otp = rand(999999, 000000);
  //Email information
  $email = $_REQUEST['email'];
  $subject = "Email Verification ChatMeow";
  $comment = "Your OTP Is:- ".$otp;
  //send email
  mail($email, $subject, $comment, "From: chatmeow@official.com");
  header("location: compare.php?otp={$otp}&mail={$email}");
  }
  else  {
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>CHATMEOW</title>
  <link rel="apple-touch-icon" sizes="180x180" href="../php/images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="../php/images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="../php/images/favicon-16x16.png">
  <link rel="manifest" href="../php/images/site.webmanifest">
  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
</head>
<body>
  <div class="wrapper">
    <section class="form login">
      <header>Verify Your Email</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="field input">
          <label>Email Address</label>
          <input type="text" name="email" placeholder="Enter your email" required>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Send OTP">
        </div>
      </form>
    </section>
  </div>
</body>
</html>
